const API_BASE = "/api/v1";

export async function fetchApi<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  const res = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
    ...options,
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`API Error ${res.status}: ${errText}`);
  }

  return res.json();
}

export const api = {
  getDashboardMetrics: () => fetchApi<any>("/dashboard/metrics"),
  
  // Payment Memory
  findMyMoney: (query: string, limit = 20) => 
    fetchApi<any>("/memory/find-my-money", {
      method: "POST",
      body: JSON.stringify({ query, limit })
    }),
  ingestProof: (raw_text: string, image_base64?: string) =>
    fetchApi<any>("/memory/ingest-proof", {
      method: "POST",
      body: JSON.stringify({ raw_text, image_base64 })
    }),

  // Relationship Graph
  getPeople: () => fetchApi<any[]>("/people"),
  getPersonCard: (id: string) => fetchApi<any>(`/people/${id}`),

  // Obligations & Receivables
  getObligations: () => fetchApi<any[]>("/obligations"),

  // Reconciliation & Honest Exceptions
  getHonestExceptions: () => fetchApi<any[]>("/reconciliation/honest-exceptions"),
  reconcileMatch: (payment_event_id: string, obligation_id?: string) =>
    fetchApi<any>("/reconciliation/match", {
      method: "POST",
      body: JSON.stringify({ payment_event_id, obligation_id })
    }),

  // Risk & Scam Shield
  evaluateRisk: (payload: any) =>
    fetchApi<any>("/risk/evaluate", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  getRiskEvents: () => fetchApi<any[]>("/risk/events"),

  // Recovery Engine
  getReceivablesAtRisk: () => fetchApi<any[]>("/recovery/at-risk"),
  dispatchRecovery: (obligation_id: string, custom_message?: string) =>
    fetchApi<any>("/recovery/dispatch", {
      method: "POST",
      body: JSON.stringify({ obligation_id, custom_message })
    }),

  // AI Approvals
  getPendingApprovals: () => fetchApi<any[]>("/approvals"),
  decideApproval: (id: string, decision: string, note?: string) =>
    fetchApi<any>(`/approvals/${id}/decision`, {
      method: "POST",
      body: JSON.stringify({ decision, note })
    }),

  // Assistant
  askAssistant: (message: string) =>
    fetchApi<any>("/assistant/query", {
      method: "POST",
      body: JSON.stringify({ message })
    }),

  // Simulation Lab
  runSimImpersonation: () => fetchApi<any>("/simulator/run-impersonation-attack", { method: "POST" }),
  runSimRecovery: () => fetchApi<any>("/simulator/run-revenue-recovery", { method: "POST" }),
  runSimOCR: () => fetchApi<any>("/simulator/run-screenshot-ocr", { method: "POST" }),

  // Audit Logs
  getAuditLogs: () => fetchApi<any[]>("/audit"),
};
